const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const router = express.Router();

const db = new sqlite3.Database("./database/db.sqlite");

router.get("/posts", (req, res) => {
    const sql = `
        SELECT posts.id, posts.title, posts.content, users.name AS author, categories.name AS category 
        FROM posts
        JOIN users ON posts.user_id = users.id
        JOIN categories ON posts.category_id = categories.id;
    `;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

router.post("/posts", (req, res) => {
    const { title, content, user_id, category_id } = req.body;
    const sql = `INSERT INTO posts (title, content, user_id, category_id) VALUES (?, ?, ?, ?)`;
    db.run(sql, [title, content, user_id, category_id], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID });
    });
});

router.put("/posts/:id", (req, res) => {
    const { title, content } = req.body;
    const sql = `UPDATE posts SET title = ?, content = ? WHERE id = ?`;
    db.run(sql, [title, content, req.params.id], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ updated: this.changes });
    });
});

router.delete("/posts/:id", (req, res) => {
    const sql = `DELETE FROM posts WHERE id = ?`;
    db.run(sql, req.params.id, function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: this.changes });
    });
});

module.exports = router;
